﻿namespace lab09.Models
{
    public enum ArticleCategory
    {
        Electronics,
        Food,
        Books,
        Clothing,
        HomeGoods
    }
}
