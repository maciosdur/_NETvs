﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace lab11.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }

}
